//
//  main.m
//  DatePickerDemo
//
//  Created by Victor  Adu on 4/29/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

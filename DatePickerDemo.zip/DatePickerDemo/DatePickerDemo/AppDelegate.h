//
//  AppDelegate.h
//  DatePickerDemo
//
//  Created by Victor  Adu on 4/29/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

//
//  ViewController.m
//  DatePickerDemo
//
//  Created by Victor  Adu on 4/29/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIDatePicker *dateLabel;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)dayDisplay:(id)sender {
    
    //grab date from selected date on the date picker.
    NSDate *chosen = [[NSDate alloc] init];
    chosen = [[self dateLabel] date];
    
    //create an NSDateFormatter
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: @"EEEE"];
    
    NSString *day = [formatter stringFromDate: chosen];
    NSString *msg = [[NSString alloc] initWithFormat:@"That's a %@", day];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"What's the Day?"
        message:msg delegate:nil cancelButtonTitle:@"OKay" otherButtonTitles:nil, nil];
    
    [alert show];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
